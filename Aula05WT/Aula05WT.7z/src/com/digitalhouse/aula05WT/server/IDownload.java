package com.digitalhouse.aula05WT.server;

import com.digitalhouse.aula05WT.model.Usuario;

public interface IDownload {

    public void baixarMusica(Usuario usuario);
}
