package com.digitalhouse.aula05WT.model;

public enum Tipo {
    FREE, PREMIUM
}
